export type BenchmarkCategoryKey =
  | 'overall'
  | 'landings'
  | 'acquisition'
  | 'wind'
  | 'waves'
  | 'boat_speed'
  | 'combined';

export interface CoastalMapType {
  id: string;
  name: string;
  code: string;
  summary: string;
  conditions: string;
  visualChallenge: string;
  routeProfile: string;
}

export interface TimelineItem {
  step: string;
  dateRange: string;
  phase: string;
  title: string;
  subtitle: string;
  description: string;
  problem: string;
  breakthrough: string;
  outcome: string;
  resultBadge: string;
  metrics: { label: string; value: string }[];
}

export interface BenchmarkModelResult {
  id: string;
  shortName: string;
  roleLabel: string;
  subtitle: string;
  barColorHex: string;
  landedCount: number;
  totalCases: number;
  overallScorePct: number;
  padVisibilityPct: number;
  categoryScores: Record<BenchmarkCategoryKey, number>;
  description: string;
}

export interface BenchmarkScenarioCase {
  id: string;
  code: string;
  category: Exclude<BenchmarkCategoryKey, 'overall' | 'landings'>;
  categoryLabel: string;
  title: string;
  conditions: string;
  results: {
    teacher_v2: 'landed' | 'fallback' | 'failed';
    visual_search_v1: 'landed' | 'fallback' | 'failed';
    vision_baseline_v1: 'landed' | 'fallback' | 'failed';
    radio_baseline_v1: 'landed' | 'fallback' | 'failed';
  };
}

export interface FlightModeSpec {
  id: string;
  step: string;
  name: string;
  trigger: string;
  activeModules: string;
  behavior: string;
  safetyGate: string;
}

export const STRICT_LANDING_CRITERIA = [
  {
    metric: '≥ 3 of 4 Feet',
    label: 'Pad Contact',
    detail: 'At least three landing gear foot spheres in active physical contact with the 600 × 600 mm elevated deck plate.',
  },
  {
    metric: '≤ 0.30 m',
    label: 'Center-of-Mass Bounds',
    detail: 'Projection of the quadrotor center of mass lies strictly inside the 0.60 × 0.60 m support polygon.',
  },
  {
    metric: '≤ 0.10 m/s',
    label: 'Horizontal Slip Speed',
    detail: 'Relative lateral velocity between the drone and the moving boat deck at touchdown.',
  },
  {
    metric: '≤ 0.05 m/s',
    label: 'Vertical Touchdown Rate',
    detail: 'Relative vertical impact speed against the wave-heaving landing pad.',
  },
  {
    metric: '< 5.0°',
    label: 'Relative Airframe Tilt',
    detail: 'Combined roll and pitch misalignment relative to the deck surface with zero tip-over.',
  },
  {
    metric: '≥ 2.0 s',
    label: 'Post-Disarm Hold',
    detail: 'PX4 disarms and the drone remains stably seated on the moving, wave-heaving pad for two continuous seconds.',
  },
];

export const DRONE_BOM_ITEMS = [
  {
    component: 'Holybro X500 V2 ARF Kit',
    role: 'Carbon-fiber airframe, brushless motors, ESCs, propellers',
    simTwin: 'x500_v2 chassis + 4 rotor actuators (0–14 N thrust each)',
    costEur: 339,
  },
  {
    component: 'Holybro Pixhawk 6C + M10 GPS',
    role: 'Primary flight controller & GNSS navigation',
    simTwin: 'Unmodified PX4 Autopilot v1.16.0 SITL at 250 Hz over MAVLink TCP',
    costEur: 339,
  },
  {
    component: 'ALLXF D-80Pro 2-Axis Gimbal Camera',
    role: 'Stabilized underslung optical sensor',
    simTwin: 'Continuous 360° pan + (-61° to +140°) tilt joint · 640×360 RGB @ 25 Hz',
    costEur: 660,
  },
  {
    component: 'Khadas Edge 2 Pro (RK3588S ARM64)',
    role: 'Onboard neural inference & geometric marker solver',
    simTwin: '25 Hz PyTorch / ONNX policy + compiled C++ FP64 TRF marker solver',
    costEur: 300,
  },
  {
    component: 'Seeed XIAO ESP32S3 + Wio-SX1262',
    role: 'Optional 868/915 MHz sub-GHz boat telemetry receiver',
    simTwin: 'Simulated noisy, delayed, or GPS-spoofed boat radio packets',
    costEur: 12,
  },
  {
    component: 'Gens ace 4S 5000 mAh LiPo + PM02 V3',
    role: 'Flight battery & power telemetry',
    simTwin: 'Full mass/inertia tensor integration (2.066 kg total takeoff weight)',
    costEur: 106,
  },
];

export const COASTAL_MAP_TYPES: CoastalMapType[] = [
  {
    id: 'island',
    name: 'Wooded Island',
    code: 'island',
    summary:
      'Forested island shorelines with sheltered coves, headland wave diffraction, dark tree-canopy water reflections, and curved >1 km circumnavigation routes.',
    conditions: 'Diffracted ocean swell · Variable headland wind',
    visualChallenge: 'Dark canopy reflections on water and curved pursuit around headlands.',
    routeProfile: '>1.0 km curved island circumnavigation with heading changes.',
  },
  {
    id: 'beach',
    name: 'Sandy Beach',
    code: 'beach',
    summary:
      'Broad shallow-slope sandy shorelines with bright nearshore surf zones, wave shoaling, and high-albedo sand glare near the cyan deck marker spectrum.',
    conditions: 'Nearshore wave shoaling · High-albedo surf glare',
    visualChallenge: 'Bright whitewater surf and sand reflections competing with deck contrast.',
    routeProfile: 'Long nearshore runs parallel to breaking surf.',
  },
  {
    id: 'city',
    name: 'Urban City',
    code: 'city',
    summary:
      'High-density harbor channels lined with piers, docks, geometric building edges, choppy harbor reflections, and up to 6 decoy vessels anchored or moving nearby.',
    conditions: 'Multi-directional harbor chop · Congested decoy traffic',
    visualChallenge: 'Sharp geometric building edges, pier clutter, and nearby decoy hulls.',
    routeProfile: 'Constrained harbor navigation channels with S-turns.',
  },
  {
    id: 'gravel',
    name: 'Gravel Coast',
    code: 'gravel',
    summary:
      'High-frequency shingle and pebble spits with steep nearshore drop-offs and cross-shore surface currents that test false-positive heatmap suppression.',
    conditions: 'Cross-shore currents · High-frequency texture noise',
    visualChallenge: 'Dense pebble shoreline textures testing search heatmap precision.',
    routeProfile: 'Coastal spit passages with lateral current drift.',
  },
  {
    id: 'rocky',
    name: 'Rocky Coast',
    code: 'rocky',
    summary:
      'Jagged basalt sea stacks, cliffs, harsh directional shadows, and steep offshore reef swells—matching the environment archetype used in the Tidewater WebGPU transfer test.',
    conditions: 'Up to 1.0 m steep swell · Up to 9.0 m/s turbulent crosswinds',
    visualChallenge: 'Steep wave heave, harsh cliff shadows, and rapid deck pitch oscillations.',
    routeProfile: 'Offshore reef passages under severe wind and wave stress.',
  },
];

export const TIMELINE_STEPS: TimelineItem[] = [
  {
    step: '01',
    dateRange: 'Oct 8 – Oct 10',
    phase: 'Cloud Dataset & End-to-End Diagnostic',
    title: 'Why Direct Neural Action Imitation Failed (0/12 Landings)',
    subtitle: 'NVIDIA L4 GPU · 1,200 Expert Episodes (~500 GB) · Telemetry Feedback Diagnosis',
    description:
      'We began in the simplest setting: the boat broadcasted its GPS coordinates over radio, and we rented a Google Cloud GPU VM (NVIDIA L4, right-sized from 64 contending workers on 32 vCPUs to 8 lockstep workers at 47.3 FPS) to record 1,200 expert landings (~500 GB). A 1.55M-parameter recurrent network trained to output flight commands directly achieved a tiny offline validation loss (0.00189), yet landed 0/12 times in closed-loop flight.',
    problem:
      'Despite 0.00189 offline Huber loss, the drone lost sight of the landing pad in 82.9% of frames and achieved 0/12 live landings.',
    breakthrough:
      'Identified two root causes: (1) feeding the policy’s own previous 6 action commands back as inputs caused a runaway closed-loop feedback loop (amplifying gimbal pan MSE by 50.9× and vertical descent MSE by 60.4×), and (2) raw ±180° angle wrap drove the gimbal into its mechanical stops. Removing previous actions and encoding all angles as continuous [sin θ, cos θ] pairs (periodic_no_action_v1) boosted closed-loop pad visibility from 17.1% to 79.0%.',
    outcome:
      'Diagnosed a runaway previous-action feedback loop (50.9× pan error) and ±180° gimbal angle wrap; removing previous actions and using continuous [sin θ, cos θ] angles raised pad visibility from 17.1% to 79.0% and motivated our decoupled architecture.',
    resultBadge: '0/12 landings → Pad visibility 17.1% to 79.0%',
    metrics: [
      { label: 'Cloud Dataset', value: '1,200 episodes (500 GB)' },
      { label: 'Closed-Loop Pad Visibility', value: '17.1% → 79.0% (4.6×)' },
      { label: 'Action Feedback Error', value: '50.9× pan / 60.4× vz MSE fixed' },
    ],
  },
  {
    step: '02',
    dateRange: 'Oct 10 – Oct 15',
    phase: 'Hybrid Perception, Geometry & Control',
    title: 'The Hybrid Marker Architecture & Zero-Shot Tidewater Transfer',
    subtitle: 'Neural Boat Tracking + Calibrated Geometric Marker Solver + Explicit PX4 Control',
    description:
      'Instead of asking a single neural network to output raw motor commands, we split the system into three specialized stages: (1) the recurrent neural network tracks the boat’s 3D motion across wave troughs, (2) a calibrated geometric solver fits the 26 cm asymmetric cyan pattern on the landing pad against camera intrinsics for exact 6-DoF pose, and (3) an explicit flight controller commands PX4 pursuit velocities and gimbal rates.',
    problem:
      'Even with 79% camera visibility, direct neural velocity predictions lacked the sub-decimeter precision required to hit a pitching 60 × 60 cm deck.',
    breakthrough:
      'Combined learned visual memory (MobileNetV3-Small + 128-unit GRU) for long-range/wave-trough tracking with nonlinear Trust-Region Reflective (TRF) geometric registration of the 26 cm cyan fiducial marker at close range.',
    outcome:
      'Jumped from 0/12 to 12/12 validation landings, 24/24 unseen procedural weather landings across all 5 coastal map families, 4/4 rusted/recolored hull landings, and 3/4 zero-shot landings in the browser-based Tidewater 3D WebGPU ocean game.',
    resultBadge: '12/12 validation · 24/24 unseen weather · 3/4 Tidewater zero-shot',
    metrics: [
      { label: 'Validation Suite', value: '12 / 12 strict landings (100%)' },
      { label: 'Unseen Procedural Weather', value: '24 / 24 across 5 map types' },
      { label: 'Tidewater WebGPU Transfer', value: '3 / 4 zero-shot (0 game frames trained)' },
    ],
  },
  {
    step: '03',
    dateRange: 'Oct 15 – Oct 18',
    phase: 'Removing Radio Dependency & Hardening (R8 → R15)',
    title: 'Vision-First Spoof Resistance & C++ FP64 Marker Solver',
    subtitle: '45.4k Spatial Acquisition Head + Bounded Post-GRU Radio Gate + Leg Masking',
    description:
      'Up to Stage 02, when the drone spawned far from the boat, it relied on the boat’s simulated SX1262 sub-GHz radio beacon for coarse GPS coordinates. If radio was disabled or spoofed, the drone failed. We trained a 45.4k-parameter Spatial Acquisition Head to locate the boat visually at long range and placed a 770-parameter Vision-First fusion gate (capped at ≤0.35 weight) after the GRU so raw radio coordinates never enter visual memory.',
    problem:
      'Marine radio beacons suffer from dropouts and GPS spoofing; furthermore, at steep gimbal look-down angles the drone’s own front carbon-fiber landing legs entered the camera view and occluded the deck marker.',
    breakthrough:
      'Kept radio out of the GRU hidden state (surviving +5 m and +20 m GPS spoofing attacks 8/8 times), added kinematic landing-leg self-occlusion masking, and replaced Python SciPy marker fitting with a compiled C++/WASM FP64 dense reverse KD-tree solver (cutting marker RMS error from 2.5–3.0 px down to 0.44–0.48 px).',
    outcome:
      'Achieved 58/60 fresh moving-boat landings (96.7%) with zero radio input, 8/8 landings under +20 m GPS spoofing, and 10/10 safe hover fallbacks when the boat was absent.',
    resultBadge: '58/60 no-radio landings (96.7%) · 0.44 px RMS marker solver',
    metrics: [
      { label: 'No-Radio Moving Landings', value: '58 / 60 (96.7%)' },
      { label: '+20 m GPS Spoof Survival', value: '8 / 8 landed (0.06–0.09 m error)' },
      { label: 'C++ FP64 Marker Error', value: '2.8 px → 0.44 px RMS' },
    ],
  },
  {
    step: '04',
    dateRange: 'Oct 20 – Nov 9',
    phase: 'Active Horizon Search & Multi-Boat Decoy Rejection',
    title: 'Finding the True Vessel Among 6 Decoys From 65 m & 135° Behind',
    subtitle: '45.7k Multi-Task SearchHead · 60 Multi-Boat SQLite Episodes + 6,000 Synthetic Stills',
    description:
      'In the final stage, no radio is active, the recovery boat spawns up to 65 m away or 135° behind the drone outside the camera field of view, and up to 6 decoy boats (3 visually similar vessels lacking the recovery pad, 3 dissimilar workboats) share the water. We built a visibility-gated Privileged Teacher v2 with a 3-phase gimbal horizon sweep and trained a multi-task SearchHead to actively scan the sea, verify vessel identity, and reject decoys.',
    problem:
      'When the target boat starts behind the drone among visually similar decoy boats with no radio beacon, a forward-looking tracker either misses the boat or approaches a decoy.',
    breakthrough:
      'Trained a 45,674-parameter multi-task SearchHead (predicting heatmap, sub-cell offsets, target presence, 4-class visual evidence stage, and 2-class true-vs-decoy identity) on 31 GB of multi-boat episodes + 6,000 synthetic stills, optimizing PyTorch SQLite worker persistence to complete 15 epochs in 45 minutes.',
    outcome:
      'On the frozen 20-mission benchmark, the camera-only Visual Search v1 student achieved 18/20 strict landings (87.8% overall score) alongside 20/20 (99.2%) for Privileged Teacher v2.',
    resultBadge: '18/20 strict benchmark landings (Visual Search v1)',
    metrics: [
      { label: 'Search Envelope', value: 'Up to 65 m range · 135° rear azimuth' },
      { label: 'Decoy Rejection', value: '3 similar + 3 dissimilar vessels' },
      { label: '20-Case Benchmark', value: '18 / 20 strict landings (87.8%)' },
    ],
  },
];

export const FLIGHT_MODES: FlightModeSpec[] = [
  {
    id: 'search',
    step: 'Mode 01',
    name: 'Active Horizon Search (SEARCH)',
    trigger: 'No radio beacon & target vessel outside initial camera frustum (up to 65 m / 135° rear bearing).',
    activeModules: 'MobileNetV3-Small + 45.7k Multi-Task SearchHead (heatmap, presence, 4-class evidence, 2-class identity)',
    behavior:
      'Holds safe loiter altitude while sweeping the 2-axis gimbal across three structured azimuth/elevation scan phases (scan_1 → scan_2 → scan_3). Evaluates candidate vessels and rejects visually similar decoy hulls that lack the AERODOCK recovery bay.',
    safetyGate: 'Requires confirmed target identity (identity_2class == target) and sustained presence probability before leaving loiter.',
  },
  {
    id: 'approach',
    step: 'Mode 02',
    name: 'Long-Range Visual Pursuit (APPROACH)',
    trigger: 'Target boat acquired visually (or via bounded ≤0.35 radio hint when far out of visual resolution).',
    activeModules: 'Spatial Softmax + 128-Unit Recurrent Pose GRU (1.55M params) + Post-GRU Bounded Radio Gate (770 params)',
    behavior:
      'Flies smooth pursuit velocity vectors toward the moving vessel while continuously centering the gimbal optical axis on the predicted deck location across wave troughs.',
    safetyGate: 'Post-GRU fusion gate caps radio influence at ≤0.35 and drops it to 0.0 once visual lock is established, neutralizing GPS spoofing.',
  },
  {
    id: 'marker_lock',
    step: 'Mode 03',
    name: 'Metric Pad Registration & Staged Descent (MARKER LOCK)',
    trigger: '26 cm asymmetric cyan fiducial marker enters camera resolution (~12 m to 0.8 m slant range).',
    activeModules: 'Compiled C++/WASM FP64 Dense Reverse KD-Tree TRF Solver + Kinematic Landing-Leg Masking',
    behavior:
      'Masks out any Holybro X500 V2 front landing gear legs entering the camera FOV, registers the 26 cm cyan marker at 0.44–0.48 px RMS error, aligns drone yaw with boat heading, and descends through staged altitude gates (5.0 m → 2.0 m → 0.8 m).',
    safetyGate: 'Neural pose confidence alone cannot authorize final descent; metric geometric marker registration is mandatory.',
  },
  {
    id: 'touchdown',
    step: 'Mode 04',
    name: 'Wave-Aware Touchdown & Disarm (TOUCHDOWN GATE)',
    trigger: 'Drone aligned over the 600 × 600 mm scissor-lift pad at terminal altitude (< 0.8 m).',
    activeModules: 'Wave-Crest Veto Gate + PX4 SITL v1.16.0 Cascaded Attitude/Rate Controller (250 Hz)',
    behavior:
      'Monitors instantaneous vertical heave velocity (vz_pad), horizontal slip (v_xy_rel), and deck pitch/roll. Vetoes touchdown during steep wave crests and commits to final contact and PX4 disarm only during a calm wave phase.',
    safetyGate: 'Requires ≤0.10 m/s horizontal slip, ≤0.05 m/s vertical speed, <5° tilt, and ≥2.0 s of stable post-disarm contact.',
  },
];

export const BENCHMARK_CATEGORY_LABELS: Record<
  BenchmarkCategoryKey,
  { label: string; description: string; unit: string }
> = {
  overall: {
    label: 'Overall Score',
    description: 'Weighted score across all 20 matched test missions (55% outcome, 20% precision, 15% safety, 10% speed/visibility).',
    unit: '%',
  },
  landings: {
    label: 'Strict Landings',
    description: 'Percentage of missions achieving full disarmed touchdown and ≥2.0 s hold on the 60×60 cm pad.',
    unit: '%',
  },
  acquisition: {
    label: 'Search & Acquisition',
    description: 'Finding the boat from 12 m to 65 m away and up to 135° behind the drone without radio.',
    unit: '%',
  },
  wind: {
    label: 'Crosswinds (up to 9 m/s)',
    description: 'Sustained crosswinds from 4.0 m/s to 9.0 m/s with 3.5 m/s turbulent gusts.',
    unit: '%',
  },
  waves: {
    label: 'Waves (up to 1.0 m)',
    description: 'Ocean swells from 0.25 m to 1.00 m pitching and heaving the boat deck.',
    unit: '%',
  },
  boat_speed: {
    label: 'Fast Boat (up to 5 m/s)',
    description: 'Pursuing and landing on a vessel moving at up to 5.0 m/s along curved routes.',
    unit: '%',
  },
  combined: {
    label: 'Decoys & Combined Stress',
    description: 'Simultaneous wind, waves, sun glare, fast turns, and 6 decoy boats.',
    unit: '%',
  },
};

export const BENCHMARK_MODELS: BenchmarkModelResult[] = [
  {
    id: 'teacher_v2',
    shortName: 'Teacher v2',
    roleLabel: 'Privileged Reference Teacher',
    subtitle: '20/20 landed · created day 27',
    barColorHex: '#9E582F',
    landedCount: 20,
    totalCases: 20,
    overallScorePct: 99.2,
    padVisibilityPct: 86.4,
    categoryScores: {
      overall: 99.2,
      landings: 100.0,
      acquisition: 99.4,
      wind: 99.1,
      waves: 98.9,
      boat_speed: 99.3,
      combined: 99.0,
    },
    description:
      'Visibility-gated expert teacher with 3-phase horizon search and wave-aware touchdown timing (upper-bound reference).',
  },
  {
    id: 'visual_search_v1',
    shortName: 'Visual Search v1',
    roleLabel: 'Final Camera-Only Student Policy',
    subtitle: '18/20 landed · created day 17',
    barColorHex: '#1F6368',
    landedCount: 18,
    totalCases: 20,
    overallScorePct: 87.8,
    padVisibilityPct: 58.2,
    categoryScores: {
      overall: 87.8,
      landings: 90.0,
      acquisition: 96.5,
      wind: 94.2,
      waves: 91.8,
      boat_speed: 88.6,
      combined: 72.4,
    },
    description:
      'Final deployed student policy (fresh-search-f62c10a2): sweeps the horizon, rejects 6 decoys, and lands with zero radio.',
  },
  {
    id: 'vision_baseline_v1',
    shortName: 'Vision Baseline v1',
    roleLabel: 'Stage 03 Hardened Tracker (R15)',
    subtitle: '11/20 landed · created day 12',
    barColorHex: '#9A6D1F',
    landedCount: 11,
    totalCases: 20,
    overallScorePct: 57.5,
    padVisibilityPct: 24.4,
    categoryScores: {
      overall: 57.5,
      landings: 55.0,
      acquisition: 58.0,
      wind: 92.5,
      waves: 64.0,
      boat_speed: 51.2,
      combined: 38.4,
    },
    description:
      'No-radio visual tracker (R15) before adding active 3-phase horizon search and multi-boat decoy discrimination.',
  },
  {
    id: 'radio_baseline_v1',
    shortName: 'Radio Baseline v1',
    roleLabel: 'Early Stage 03 Baseline (Oct 15)',
    subtitle: '7/20 landed · created day 7',
    barColorHex: '#3B667E',
    landedCount: 7,
    totalCases: 20,
    overallScorePct: 54.9,
    padVisibilityPct: 33.7,
    categoryScores: {
      overall: 54.9,
      landings: 35.0,
      acquisition: 56.4,
      wind: 88.0,
      waves: 61.5,
      boat_speed: 48.0,
      combined: 36.2,
    },
    description:
      'Earlier hybrid baseline prior to C++ FP64 dense marker fitting, landing-leg occlusion masking, and active visual search.',
  },
];

export const BENCHMARK_SCENARIOS: BenchmarkScenarioCase[] = [
  {
    id: '01',
    code: '01_A1_near_front',
    category: 'acquisition',
    categoryLabel: 'Cat A · Search & Acquisition',
    title: 'Near Front (12 m)',
    conditions: 'Boat 12 m ahead · 1.5 m/s cruise · Calm sea · No radio',
    results: { teacher_v2: 'landed', visual_search_v1: 'landed', vision_baseline_v1: 'landed', radio_baseline_v1: 'landed' },
  },
  {
    id: '02',
    code: '02_A2_mid_front_offset',
    category: 'acquisition',
    categoryLabel: 'Cat A · Search & Acquisition',
    title: 'Mid-Range Offset (28 m, 25°)',
    conditions: 'Boat 28 m ahead · 25° lateral offset · 2.0 m/s · No radio',
    results: { teacher_v2: 'landed', visual_search_v1: 'landed', vision_baseline_v1: 'landed', radio_baseline_v1: 'landed' },
  },
  {
    id: '03',
    code: '03_A3_far_front_50m',
    category: 'acquisition',
    categoryLabel: 'Cat A · Search & Acquisition',
    title: 'Long-Range Front (50 m)',
    conditions: 'Boat 50 m ahead · 2.5 m/s · Sub-pixel marker, requires hull/wake lock',
    results: { teacher_v2: 'landed', visual_search_v1: 'landed', vision_baseline_v1: 'landed', radio_baseline_v1: 'failed' },
  },
  {
    id: '04',
    code: '04_A4_side_azimuth_90deg',
    category: 'acquisition',
    categoryLabel: 'Cat A · Search & Acquisition',
    title: 'Beam Bearing Search (35 m, 90°)',
    conditions: 'Boat 35 m at 90° side bearing outside initial camera FOV · No radio',
    results: { teacher_v2: 'landed', visual_search_v1: 'landed', vision_baseline_v1: 'failed', radio_baseline_v1: 'failed' },
  },
  {
    id: '05',
    code: '05_A5_rear_search_135deg',
    category: 'acquisition',
    categoryLabel: 'Cat A · Search & Acquisition',
    title: 'Rear Horizon Sweep (45–65 m, 135°)',
    conditions: 'Boat 45–65 m at 135° behind drone · Requires full 3-phase gimbal scan',
    results: { teacher_v2: 'landed', visual_search_v1: 'landed', vision_baseline_v1: 'failed', radio_baseline_v1: 'failed' },
  },
  {
    id: '06',
    code: '06_W1_wind_4ms',
    category: 'wind',
    categoryLabel: 'Cat W · Crosswind & Gusts',
    title: 'Moderate Crosswind (4.0 m/s)',
    conditions: '4.0 m/s sustained crosswind + 1.5 m/s gusts · 2.0 m/s boat speed',
    results: { teacher_v2: 'landed', visual_search_v1: 'landed', vision_baseline_v1: 'landed', radio_baseline_v1: 'landed' },
  },
  {
    id: '07',
    code: '07_W2_wind_65ms',
    category: 'wind',
    categoryLabel: 'Cat W · Crosswind & Gusts',
    title: 'Strong Crosswind (6.5 m/s)',
    conditions: '6.5 m/s sustained crosswind + 2.5 m/s gusts · 2.5 m/s boat speed',
    results: { teacher_v2: 'landed', visual_search_v1: 'landed', vision_baseline_v1: 'landed', radio_baseline_v1: 'landed' },
  },
  {
    id: '08',
    code: '08_W3_wind_9ms',
    category: 'wind',
    categoryLabel: 'Cat W · Crosswind & Gusts',
    title: 'Severe Crosswind (9.0 m/s)',
    conditions: '9.0 m/s crosswind + 3.5 m/s gusts · High airframe tilt & leg occlusion',
    results: { teacher_v2: 'landed', visual_search_v1: 'landed', vision_baseline_v1: 'landed', radio_baseline_v1: 'failed' },
  },
  {
    id: '09',
    code: '09_V1_waves_025m',
    category: 'waves',
    categoryLabel: 'Cat V · Ocean Wave Heave',
    title: 'Gentle Swell (0.25 m Hs)',
    conditions: '0.25 m significant wave height · Gentle deck heave & pitch',
    results: { teacher_v2: 'landed', visual_search_v1: 'landed', vision_baseline_v1: 'landed', radio_baseline_v1: 'landed' },
  },
  {
    id: '10',
    code: '10_V2_waves_060m',
    category: 'waves',
    categoryLabel: 'Cat V · Ocean Wave Heave',
    title: 'Moderate Swell (0.60 m Hs)',
    conditions: '0.60 m significant wave height · Continuous pitch & roll oscillation',
    results: { teacher_v2: 'landed', visual_search_v1: 'landed', vision_baseline_v1: 'landed', radio_baseline_v1: 'failed' },
  },
  {
    id: '11',
    code: '11_V3_waves_100m',
    category: 'waves',
    categoryLabel: 'Cat V · Ocean Wave Heave',
    title: 'Steep Ocean Swell (1.00 m Hs)',
    conditions: '1.00 m steep 4-component swell · Requires wave-crest touchdown veto gate',
    results: { teacher_v2: 'landed', visual_search_v1: 'landed', vision_baseline_v1: 'failed', radio_baseline_v1: 'failed' },
  },
  {
    id: '12',
    code: '12_S1_speed_15ms',
    category: 'boat_speed',
    categoryLabel: 'Cat S · Fast Vessel Pursuit',
    title: 'Steady Cruise (1.5 m/s)',
    conditions: '1.5 m/s steady boat speed along coastal route',
    results: { teacher_v2: 'landed', visual_search_v1: 'landed', vision_baseline_v1: 'landed', radio_baseline_v1: 'landed' },
  },
  {
    id: '13',
    code: '13_S2_speed_35ms',
    category: 'boat_speed',
    categoryLabel: 'Cat S · Fast Vessel Pursuit',
    title: 'Fast Cruise (3.5 m/s)',
    conditions: '3.5 m/s vessel speed · Requires feed-forward velocity pursuit',
    results: { teacher_v2: 'landed', visual_search_v1: 'landed', vision_baseline_v1: 'landed', radio_baseline_v1: 'failed' },
  },
  {
    id: '14',
    code: '14_S3_speed_50ms',
    category: 'boat_speed',
    categoryLabel: 'Cat S · Fast Vessel Pursuit',
    title: 'Sprint Pursuit (5.0 m/s)',
    conditions: '5.0 m/s fast vessel sprint · Steep forward drone pitch angle',
    results: { teacher_v2: 'landed', visual_search_v1: 'landed', vision_baseline_v1: 'failed', radio_baseline_v1: 'failed' },
  },
  {
    id: '15',
    code: '15_S4_curvy_fast',
    category: 'boat_speed',
    categoryLabel: 'Cat S · Fast Vessel Pursuit',
    title: 'Fast S-Turn Channel (4.0 m/s)',
    conditions: '4.0 m/s continuous S-turn route with rapid boat yaw rotation',
    results: { teacher_v2: 'landed', visual_search_v1: 'fallback', vision_baseline_v1: 'failed', radio_baseline_v1: 'failed' },
  },
  {
    id: '16',
    code: '16_C1_moderate_combined',
    category: 'combined',
    categoryLabel: 'Cat C · Decoys & Combined Stress',
    title: 'Combined Wind, Waves & Turn',
    conditions: '5.0 m/s wind + 0.5 m waves + 3.0 m/s turning boat',
    results: { teacher_v2: 'landed', visual_search_v1: 'landed', vision_baseline_v1: 'landed', radio_baseline_v1: 'landed' },
  },
  {
    id: '17',
    code: '17_C2_glare_wind_waves',
    category: 'combined',
    categoryLabel: 'Cat C · Decoys & Combined Stress',
    title: 'Specular Sun Glare + Rough Sea',
    conditions: 'Low-angle specular sun glare + 6.5 m/s wind + 0.6 m waves',
    results: { teacher_v2: 'landed', visual_search_v1: 'landed', vision_baseline_v1: 'failed', radio_baseline_v1: 'failed' },
  },
  {
    id: '18',
    code: '18_C3_decoys_coastal',
    category: 'combined',
    categoryLabel: 'Cat C · Decoys & Combined Stress',
    title: '6 Decoy Vessels in Island Channel',
    conditions: '3 visually similar + 3 dissimilar decoy boats · No radio',
    results: { teacher_v2: 'landed', visual_search_v1: 'landed', vision_baseline_v1: 'failed', radio_baseline_v1: 'failed' },
  },
  {
    id: '19',
    code: '19_C4_decoys_harbor',
    category: 'combined',
    categoryLabel: 'Cat C · Decoys & Combined Stress',
    title: 'Urban Harbor + 6 Decoys + Off-Axis',
    conditions: 'City harbor clutter + 6 decoys + off-axis spawn + 5.5 m/s wind',
    results: { teacher_v2: 'landed', visual_search_v1: 'landed', vision_baseline_v1: 'failed', radio_baseline_v1: 'failed' },
  },
  {
    id: '20',
    code: '20_C5_decoys_hard_stress',
    category: 'combined',
    categoryLabel: 'Cat C · Decoys & Combined Stress',
    title: 'Maximum Combined Stress + 6 Decoys',
    conditions: '8.0 m/s wind + 0.9 m waves + 4.5 m/s turning boat + 6 decoys + glare',
    results: { teacher_v2: 'landed', visual_search_v1: 'fallback', vision_baseline_v1: 'failed', radio_baseline_v1: 'failed' },
  },
];

export function getBenchmarkComparisonByCategory(category: BenchmarkCategoryKey) {
  const meta = BENCHMARK_CATEGORY_LABELS[category];
  const entries = BENCHMARK_MODELS.map((model) => ({
    id: model.id,
    shortName: model.shortName,
    roleLabel: model.roleLabel,
    subtitle: model.subtitle,
    barColorHex: model.barColorHex,
    landedCount: model.landedCount,
    totalCases: model.totalCases,
    padVisibilityPct: model.padVisibilityPct,
    score: Number(model.categoryScores[category].toFixed(1)),
    description: model.description,
  }));

  const searchStudent = entries.find((e) => e.id === 'visual_search_v1');
  const visionBaseline = entries.find((e) => e.id === 'vision_baseline_v1');
  const studentVsVisionDelta =
    searchStudent && visionBaseline
      ? Number((searchStudent.score - visionBaseline.score).toFixed(1))
      : 0;

  return {
    category,
    label: meta.label,
    description: meta.description,
    unit: meta.unit,
    entries,
    studentVsVisionDelta,
  };
}

export function resolveInitialHeroPhase(searchString: string): 'title_intro' | 'video_playing' {
  const params = new URLSearchParams(searchString);
  if (params.get('autostart') === '1') {
    return 'video_playing';
  }
  return 'title_intro';
}
