import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import {
  COASTAL_MAP_TYPES,
  TIMELINE_STEPS,
  BENCHMARK_MODELS,
  STRICT_LANDING_CRITERIA,
  DRONE_BOM_ITEMS,
  FLIGHT_MODES,
  BENCHMARK_SCENARIOS,
  getBenchmarkComparisonByCategory,
  resolveInitialHeroPhase,
} from './projectData.ts';
import {
  SPRING_SNAPPY,
  SPRING_SURFACE,
  SPRING_GENTLE,
  EXIT_ASYMMETRIC,
  getStaggerContainerVariants,
  getStaggerItemVariants,
  getPanelSwapVariants,
} from '../utils/motion.ts';

describe('AeroDock Showcase Logic & 2026 Motion Physics', () => {
  it('defines all 5 procedural coastal map types', () => {
    assert.equal(COASTAL_MAP_TYPES.length, 5);
    assert.deepEqual(
      COASTAL_MAP_TYPES.map((m) => m.id),
      ['island', 'beach', 'city', 'gravel', 'rocky']
    );
  });

  it('defines the 4 chronological engineering milestones with metrics and diagnostics', () => {
    assert.equal(TIMELINE_STEPS.length, 4);
    for (const step of TIMELINE_STEPS) {
      assert.ok(step.problem.length > 10);
      assert.ok(step.breakthrough.length > 10);
      assert.ok(step.metrics.length === 3);
    }
  });

  it('defines the 6 strict physical landing criteria and 1,756 EUR hardware BOM', () => {
    assert.equal(STRICT_LANDING_CRITERIA.length, 6);
    assert.equal(DRONE_BOM_ITEMS.length, 6);
    const totalCost = DRONE_BOM_ITEMS.reduce((sum, item) => sum + item.costEur, 0);
    assert.equal(totalCost, 1756);
  });

  it('defines the 4 closed-loop flight modes and all 20 benchmark scenarios', () => {
    assert.equal(FLIGHT_MODES.length, 4);
    assert.equal(BENCHMARK_SCENARIOS.length, 20);
    const teacherLanded = BENCHMARK_SCENARIOS.filter(
      (s) => s.results.teacher_v2 === 'landed'
    ).length;
    const studentLanded = BENCHMARK_SCENARIOS.filter(
      (s) => s.results.visual_search_v1 === 'landed'
    ).length;
    assert.equal(teacherLanded, 20);
    assert.equal(studentLanded, 18);
  });

  it('returns canonical 20-case benchmark scores matching the 4-model Säulendiagramm', () => {
    const overall = getBenchmarkComparisonByCategory('overall');
    assert.equal(overall.entries.length, 4);
    assert.deepEqual(
      overall.entries.map((e) => ({ id: e.id, score: e.score, landed: e.landedCount })),
      [
        { id: 'teacher_v2', score: 99.2, landed: 20 },
        { id: 'visual_search_v1', score: 87.8, landed: 18 },
        { id: 'vision_baseline_v1', score: 57.5, landed: 11 },
        { id: 'radio_baseline_v1', score: 54.9, landed: 7 },
      ]
    );
    assert.equal(overall.studentVsVisionDelta, 30.3);
  });

  it('resolves hero initial phase from ?autostart=1 query parameter', () => {
    assert.equal(resolveInitialHeroPhase(''), 'title_intro');
    assert.equal(resolveInitialHeroPhase('?autostart=1'), 'video_playing');
  });

  it('enforces 2026 spring physics parameters and reduced-motion accessibility fallback', () => {
    assert.deepEqual(SPRING_SNAPPY, {
      type: 'spring',
      stiffness: 400,
      damping: 28,
      mass: 0.8,
    });
    assert.deepEqual(SPRING_SURFACE, {
      type: 'spring',
      stiffness: 260,
      damping: 25,
      mass: 1,
    });
    assert.deepEqual(SPRING_GENTLE, {
      type: 'spring',
      stiffness: 140,
      damping: 24,
      mass: 1.1,
    });
    assert.equal((EXIT_ASYMMETRIC as { duration: number }).duration, 0.15);

    const activeStagger = getStaggerContainerVariants(false);
    assert.deepEqual(activeStagger.visible, {
      opacity: 1,
      transition: { staggerChildren: 0.05, delayChildren: 0.03 },
    });

    const reducedItem = getStaggerItemVariants(true);
    assert.deepEqual(reducedItem.hidden, { opacity: 0 });

    const activePanel = getPanelSwapVariants(false);
    assert.deepEqual(activePanel.initial, {
      opacity: 0,
      y: 6,
      scale: 0.985,
    });
  });

  it('has 4 benchmark models configured', () => {
    assert.equal(BENCHMARK_MODELS.length, 4);
  });
});
