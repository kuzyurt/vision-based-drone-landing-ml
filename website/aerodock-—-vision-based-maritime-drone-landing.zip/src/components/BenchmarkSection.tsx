import React, { useState } from 'react';
import { AnimatePresence, motion, useReducedMotion } from 'motion/react';
import {
  BENCHMARK_CATEGORY_LABELS,
  BENCHMARK_MODELS,
  BenchmarkCategoryKey,
  getBenchmarkComparisonByCategory,
} from '../data/projectData';
import {
  EXIT_ASYMMETRIC,
  REDUCED_MOTION_TRANSITION,
  SPRING_GENTLE,
  SPRING_SNAPPY,
  SPRING_SURFACE,
} from '../utils/motion';

const CATEGORY_ORDER: BenchmarkCategoryKey[] = [
  'overall',
  'landings',
  'acquisition',
  'wind',
  'waves',
  'boat_speed',
  'combined',
];

export const BenchmarkSection: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<BenchmarkCategoryKey>('overall');
  const prefersReducedMotion = useReducedMotion();
  const comparison = getBenchmarkComparisonByCategory(selectedCategory);

  return (
    <section
      id="benchmarks"
      className="py-24 md:py-32 bg-[var(--surface-subtle)] border-b border-[var(--border-hairline)]"
    >
      <div className="max-w-[1280px] mx-auto px-6 md:px-10">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: prefersReducedMotion ? 0 : 12 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={SPRING_GENTLE}
          className="max-w-3xl"
        >
          <h2
            className="type-h2 font-bold text-[var(--ink-primary)]"
            style={{ textWrap: 'balance' }}
          >
            20-Mission Benchmark
          </h2>
          <p className="mt-5 type-body text-[var(--ink-secondary)]">
            Every model generation was tested on the exact same 20 ocean missions—covering
            long-range search up to 65 m away, 9 m/s crosswinds, 1.0 m waves, 5 m/s boat speed,
            and 6 decoy boats.
          </p>
        </motion.div>

        {/* Single-Row Category Filter Bar with Shared-Layout Spring Pill (Zero orphan wrapping) */}
        <div
          className="mt-10 flex items-center justify-between gap-1 p-1.5 rounded-lg bg-[var(--surface-canvas)] border border-[var(--border-hairline)] overflow-x-auto"
          role="tablist"
          aria-label="Benchmark Categories"
        >
          {CATEGORY_ORDER.map((catKey) => {
            const isSelected = catKey === selectedCategory;
            return (
              <motion.button
                key={catKey}
                type="button"
                role="tab"
                aria-selected={isSelected}
                onClick={() => setSelectedCategory(catKey)}
                whileTap={prefersReducedMotion ? undefined : { scale: 0.97 }}
                transition={SPRING_SNAPPY}
                className={`relative flex-1 px-3 py-2 rounded-md text-sm font-medium cursor-pointer whitespace-nowrap shrink-0 transition-colors duration-150 ${
                  isSelected
                    ? 'text-[var(--surface-canvas)]'
                    : 'text-[var(--ink-secondary)] hover:text-[var(--ink-primary)]'
                }`}
              >
                {isSelected && (
                  <motion.span
                    layoutId="benchmark-category-active-pill"
                    transition={SPRING_SNAPPY}
                    className="absolute inset-0 rounded-md bg-[var(--ink-primary)]"
                  />
                )}
                <span className="relative z-10">{BENCHMARK_CATEGORY_LABELS[catKey].label}</span>
              </motion.button>
            );
          })}
        </div>

        {/* Säulendiagramm Container */}
        <div className="mt-6 rounded-lg border border-[var(--border-hairline)] bg-[#F7F9F7] p-8 md:p-12">
          <div className="pb-6 border-b border-[var(--border-hairline)]">
            <AnimatePresence mode="wait">
              <motion.div
                key={comparison.category}
                initial={prefersReducedMotion ? { opacity: 0 } : { opacity: 0, y: 6 }}
                animate={
                  prefersReducedMotion
                    ? { opacity: 1, transition: REDUCED_MOTION_TRANSITION }
                    : { opacity: 1, y: 0, transition: SPRING_SURFACE }
                }
                exit={
                  prefersReducedMotion
                    ? { opacity: 0, transition: REDUCED_MOTION_TRANSITION }
                    : { opacity: 0, y: -4, transition: EXIT_ASYMMETRIC }
                }
              >
                <h3 className="font-display font-bold text-2xl text-[#17252A]">
                  {comparison.label}
                </h3>
                <p className="mt-1 type-body text-[#3B4D54]">{comparison.description}</p>
              </motion.div>
            </AnimatePresence>
          </div>

          {/* Bar Chart Grid (0 to 100) */}
          <div className="mt-14 relative">
            <div className="relative h-80 flex flex-col justify-between pointer-events-none">
              {[100, 75, 50, 25, 0].map((tick) => (
                <div key={tick} className="flex items-center w-full h-0">
                  <span className="w-10 text-right pr-3 font-mono text-sm font-medium text-[#52646B] tabular-nums -translate-y-0.5">
                    {tick}
                  </span>
                  <div
                    className={`flex-1 h-px ${
                      tick === 0 ? 'bg-[#8FA1A8]' : 'bg-[#D3DDD9]'
                    }`}
                  />
                </div>
              ))}
            </div>

            {/* Spring-Animated Bars (Smooth layout transition, never scale(0)) */}
            <div className="absolute inset-0 pl-12 pr-2 grid grid-cols-4 gap-4 sm:gap-10 h-80">
              {comparison.entries.map((entry) => {
                const barHeightPct = Math.max(Math.min(entry.score, 100), 2);
                return (
                  <div key={entry.id} className="relative h-full flex justify-center">
                    <motion.span
                      layout
                      transition={prefersReducedMotion ? REDUCED_MOTION_TRANSITION : SPRING_SURFACE}
                      className="absolute font-mono font-bold text-lg sm:text-2xl text-[#17252A] tabular-nums"
                      style={{ bottom: `calc(${barHeightPct}% + 10px)` }}
                    >
                      {entry.score.toFixed(1)}
                      {comparison.unit}
                    </motion.span>

                    <motion.div
                      layout
                      transition={prefersReducedMotion ? REDUCED_MOTION_TRANSITION : SPRING_SURFACE}
                      className="absolute bottom-0 w-full max-w-[116px] rounded-t-xs origin-bottom"
                      style={{
                        height: `${barHeightPct}%`,
                        backgroundColor: entry.barColorHex,
                      }}
                    />
                  </div>
                );
              })}
            </div>
          </div>

          {/* X-Axis Labels */}
          <div className="pl-12 pr-2 mt-5 grid grid-cols-4 gap-4 sm:gap-10 text-center">
            {comparison.entries.map((entry) => (
              <div key={entry.id} className="flex flex-col items-center">
                <span className="font-display font-bold text-base sm:text-lg text-[#17252A]">
                  {entry.shortName}
                </span>
                <span className="mt-1 text-sm text-[#52646B] tabular-nums">
                  {entry.subtitle}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Clean 2x2 Model Summary Grid */}
        <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-6 items-stretch">
          {BENCHMARK_MODELS.map((model) => (
            <motion.div
              key={model.id}
              whileHover={prefersReducedMotion ? undefined : { y: -2 }}
              transition={SPRING_SURFACE}
              className="rounded-lg border border-[var(--border-hairline)] bg-[var(--surface-elevated)] p-7 flex flex-col justify-start"
            >
              <h4 className="font-display font-bold text-xl text-[var(--ink-primary)]">
                {model.shortName} ({model.landedCount}/{model.totalCases} Landed ·{' '}
                {model.overallScorePct}%)
              </h4>
              <p className="mt-2 type-body text-[var(--ink-secondary)]">
                {model.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
