import React from 'react';
import { motion, useReducedMotion } from 'motion/react';
import { MediaPlaceholder } from './MediaPlaceholder';
import {
  SPRING_GENTLE,
  getStaggerContainerVariants,
  getStaggerItemVariants,
} from '../utils/motion';

const SYSTEM_PILLARS = [
  {
    title: 'Custom Boat & Drone',
    body: 'A 219 kg boat with sliding hangar doors and a lifting 60 × 60 cm landing pad, paired with a 2 kg quadrotor and an underslung 2-axis gimbal camera.',
  },
  {
    title: 'Real Autopilot & Physics',
    body: 'Unmodified PX4 flight-controller software (250 Hz) paired with 1,000 Hz MuJoCo physics simulating 4-wave ocean swells, hull buoyancy, and 3D wind gusts.',
  },
  {
    title: 'Camera-Only Landing',
    body: 'Searches the horizon visually, distinguishes the recovery boat from 6 decoy vessels, and lands reliably on the pitching pad without a GPS radio beacon.',
  },
];

export const OverviewSection: React.FC = () => {
  const prefersReducedMotion = useReducedMotion();
  const containerVariants = getStaggerContainerVariants(prefersReducedMotion);
  const itemVariants = getStaggerItemVariants(prefersReducedMotion);

  return (
    <section
      id="overview"
      className="py-24 md:py-32 bg-[var(--surface-canvas)] border-b border-[var(--border-hairline)]"
    >
      <div className="max-w-[1280px] mx-auto px-6 md:px-10">
        {/* Asymmetric 12-Column Split: 5-Column Editorial Proposition + 7-Column Video Frame */}
        <motion.div
          initial={{ opacity: 0, y: prefersReducedMotion ? 0 : 12 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={SPRING_GENTLE}
          className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-center"
        >
          <div className="lg:col-span-5 flex flex-col justify-center space-y-6">
            <h2
              className="type-h2 font-bold text-[var(--ink-primary)]"
              style={{ textWrap: 'balance' }}
            >
              Landing a drone on a moving boat at sea.
            </h2>

            <p className="type-body text-[var(--ink-secondary)]">
              Landing a quadrotor on solid ground is straightforward because the landing pad stays
              still. Out on the ocean, a small boat’s{' '}
              <strong className="font-semibold text-[var(--ink-primary)]">
                60 × 60 cm recovery deck
              </strong>{' '}
              is constantly moving forward (up to 5 m/s), turning along the coast, and pitching up
              and down on 1-meter ocean waves while strong crosswinds (up to 9 m/s) push the drone
              sideways.
            </p>

            <p className="type-body text-[var(--ink-secondary)]">
              In this project, we engineered the complete system from scratch: we designed the
              recovery boat and drone in CAD, simulated both vehicles in realistic ocean waves and
              wind, and trained a vision-based flight system that finds the boat with its onboard
              camera, ignores decoy boats, and lands safely on the moving deck.
            </p>
          </div>

          <div className="lg:col-span-7 flex">
            <MediaPlaceholder
              text="Video Montage Placeholder: The drone approaching and landing on the moving boat across different weather conditions, wave heights, and coastlines."
            />
          </div>
        </motion.div>

        {/* Open Typographic 3-Column Strip with 1px Top Hairlines (Zero card boxes or spreadsheet cells) */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.2 }}
          className="mt-20 grid grid-cols-1 md:grid-cols-3 gap-10"
        >
          {SYSTEM_PILLARS.map((pillar) => (
            <motion.div
              key={pillar.title}
              variants={itemVariants}
              className="pt-7 border-t border-[var(--border-hairline)] flex flex-col justify-start"
            >
              <h3 className="font-display font-bold text-2xl text-[var(--ink-primary)]">
                {pillar.title}
              </h3>
              <p className="mt-3 type-body text-[var(--ink-secondary)]">{pillar.body}</p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};
