import React from 'react';
import { motion, useReducedMotion } from 'motion/react';
import { MediaPlaceholder } from './MediaPlaceholder';
import {
  SPRING_GENTLE,
  SPRING_SURFACE,
  getStaggerContainerVariants,
  getStaggerItemVariants,
} from '../utils/motion';

const FOUR_MODULES = [
  {
    number: '1',
    title: 'Active Horizon Search & Decoy Rejection',
    description:
      'A MobileNetV3-Small camera backbone paired with a multi-task Search Network scans 640 × 360 gimbal frames at 25 Hz. When the boat starts up to 65 m away or behind the drone, it sweeps the horizon, spots the boat, and distinguishes the real recovery boat from 6 decoy boats.',
  },
  {
    number: '2',
    title: 'Recurrent Motion Memory (GRU)',
    description:
      'A 128-unit GRU memory network combines visual keypoints with continuous sin/cos camera and drone angles to remember the boat’s 3D position and velocity across wave troughs—without feeding previous actions back into the loop.',
  },
  {
    number: '3',
    title: 'Spoof-Resistant Radio Gate',
    description:
      'If an optional SX1262 boat radio signal is present, it is never fed into the memory network. Instead, a post-memory gate caps radio influence at ≤ 0.35 and drops it to zero once the camera locks on—surviving +20 m GPS spoofing without crashing.',
  },
  {
    number: '4',
    title: 'Geometric Pad Solver & Wave-Timed Touchdown',
    description:
      'At close range, a compiled C++ solver locks onto the 26 cm cyan deck pattern at 0.44-pixel accuracy (while masking out the drone’s own landing legs), aligns with the deck, and waits for a calm wave phase before commanding PX4 to land.',
  },
];

export const ArchitectureSection: React.FC = () => {
  const prefersReducedMotion = useReducedMotion();
  const containerVariants = getStaggerContainerVariants(prefersReducedMotion);
  const itemVariants = getStaggerItemVariants(prefersReducedMotion);

  return (
    <section
      id="architecture"
      className="py-24 md:py-32 bg-[var(--surface-canvas)] border-b border-[var(--border-hairline)]"
    >
      <div className="max-w-[1280px] mx-auto px-6 md:px-10">
        {/* Asymmetric 5/7 Split: Control Loop Thesis + Architecture Plate */}
        <motion.div
          initial={{ opacity: 0, y: prefersReducedMotion ? 0 : 12 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={SPRING_GENTLE}
          className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-center"
        >
          <div className="lg:col-span-5 flex flex-col justify-center space-y-6">
            <h2
              className="type-h2 font-bold text-[var(--ink-primary)]"
              style={{ textWrap: 'balance' }}
            >
              How the Final System Works
            </h2>

            <p className="type-body text-[var(--ink-secondary)]">
              Instead of relying on a single black-box network to output raw motor commands, our
              final architecture separates visual search, motion memory, radio filtering, and
              geometric pad tracking.
            </p>

            <p className="type-body text-[var(--ink-secondary)]">
              Every 40 milliseconds (25 Hz), the policy reads the gimbal camera image and the
              drone’s own flight sensors, updates its estimate of the moving deck, and sends
              smooth velocity and camera-aiming commands to the PX4 flight controller.
            </p>
          </div>

          <div className="lg:col-span-7 flex">
            <MediaPlaceholder
              text="Architecture Diagram Placeholder: Visual flowchart showing how camera images, recurrent motion memory, the spoof-resistant radio gate, and the geometric pad solver connect to PX4."
            />
          </div>
        </motion.div>

        {/* Clean 2x2 Grid of the 4 System Building Blocks */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.1 }}
          className="mt-16 grid grid-cols-1 md:grid-cols-2 gap-8 items-stretch"
        >
          {FOUR_MODULES.map((mod) => (
            <motion.div
              key={mod.number}
              variants={itemVariants}
              whileHover={prefersReducedMotion ? undefined : { y: -2 }}
              transition={SPRING_SURFACE}
              className="rounded-lg border border-[var(--border-hairline)] bg-[var(--surface-subtle)] p-8 md:p-10 flex flex-col justify-start space-y-3"
            >
              <h3 className="font-display font-bold text-2xl text-[var(--ink-primary)]">
                {mod.number}. {mod.title}
              </h3>
              <p className="type-body text-[var(--ink-secondary)]">{mod.description}</p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};
