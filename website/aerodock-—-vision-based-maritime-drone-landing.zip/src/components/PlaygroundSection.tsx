import React, { useState } from 'react';
import { AnimatePresence, motion, useReducedMotion } from 'motion/react';
import { COASTAL_MAP_TYPES } from '../data/projectData';
import { MediaPlaceholder } from './MediaPlaceholder';
import {
  SPRING_GENTLE,
  SPRING_SNAPPY,
  getPanelSwapVariants,
} from '../utils/motion';

export const PlaygroundSection: React.FC = () => {
  const [selectedMapId, setSelectedMapId] = useState<string>(COASTAL_MAP_TYPES[0].id);
  const prefersReducedMotion = useReducedMotion();
  const panelVariants = getPanelSwapVariants(prefersReducedMotion);

  const activeMap =
    COASTAL_MAP_TYPES.find((m) => m.id === selectedMapId) ?? COASTAL_MAP_TYPES[0];

  return (
    <section
      id="playground"
      className="py-24 md:py-32 bg-[var(--surface-canvas)] border-b border-[var(--border-hairline)]"
    >
      <div className="max-w-[1280px] mx-auto px-6 md:px-10">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: prefersReducedMotion ? 0 : 12 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={SPRING_GENTLE}
          className="max-w-3xl"
        >
          <h2
            className="type-h2 font-bold text-[var(--ink-primary)]"
            style={{ textWrap: 'balance' }}
          >
            Training in MuJoCo vs. Testing in Tidewater
          </h2>
          <p className="mt-5 type-body text-[var(--ink-secondary)]">
            A key question for any vision-based AI is whether it truly learned how to fly and
            land, or whether it simply memorized the graphics of its training simulator. That is
            why this project separates physics training from visual transfer testing across two
            distinct environments.
          </p>
        </motion.div>

        {/* 2-Column Environment Comparison with Clean Gap & Rounded-lg Geometry */}
        <div className="mt-12 grid grid-cols-1 lg:grid-cols-2 gap-8 items-stretch">
          <div className="rounded-lg bg-[var(--surface-subtle)] border border-[var(--border-hairline)] p-8 md:p-10 flex flex-col justify-center space-y-4">
            <h3 className="font-display font-bold text-2xl md:text-3xl text-[var(--ink-primary)]">
              1. The MuJoCo Training Area
            </h3>
            <p className="type-body text-[var(--ink-secondary)]">
              <strong className="font-semibold text-[var(--ink-primary)]">
                Simpler graphics, superior physics.
              </strong>{' '}
              All data collection and neural network training happened in MuJoCo. While its
              built-in camera graphics are relatively simple, its 1,000 Hz physics engine
              accurately models 4-component ocean waves, hull buoyancy, 3D turbulent wind gusts,
              rotor drag, and exact physical contact between the drone’s landing legs and the
              moving pad.
            </p>
          </div>

          <div className="rounded-lg bg-[var(--surface-obsidian)] text-[var(--surface-canvas)] border border-[var(--border-hairline-dark)] p-8 md:p-10 flex flex-col justify-center space-y-4">
            <h3 className="font-display font-bold text-2xl md:text-3xl text-white">
              2. The Tidewater 3D Web Game
            </h3>
            <p className="type-body text-neutral-200">
              <strong className="font-semibold text-white">
                Realistic ocean &amp; coastline graphics.
              </strong>{' '}
              Tidewater is an open-source 3D browser game with realistic WebGPU water waves,
              whitewater foam, and rocky coastlines. Because we designed our model to generalize
              and not overfit to MuJoCo’s simple graphics, the MuJoCo-trained policy works{' '}
              <strong className="font-semibold text-[var(--accent-primary-bright)]">
                zero-shot inside Tidewater
              </strong>{' '}
              (landing 3 out of 4 times in rough reef waves) without ever training on a single
              frame of Tidewater.
            </p>
          </div>
        </div>

        {/* 5 Auto-Generated Coastlines Interactive Explorer */}
        <motion.div
          initial={{ opacity: 0, y: prefersReducedMotion ? 0 : 12 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={SPRING_GENTLE}
          className="mt-20 pt-16 border-t border-[var(--border-hairline)]"
        >
          <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6">
            <div className="max-w-2xl space-y-3">
              <h3 className="font-display font-bold text-2xl md:text-3xl text-[var(--ink-primary)]">
                5 Auto-Generated Coastal Map Types
              </h3>
              <p className="type-body text-[var(--ink-secondary)]">
                To prevent the AI from memorizing a fixed path or background during MuJoCo training,
                an automatic world generator creates a fresh shoreline (&gt;1 km), randomizes sun
                glare and wave heights, and places up to 6 decoy boats every episode across five
                coastal map types:
              </p>
            </div>

            {/* Single-Row Segmented Tab Bar (Zero orphan wrapping) */}
            <div
              className="inline-flex items-center gap-1 p-1 rounded-lg bg-[var(--surface-subtle)] border border-[var(--border-hairline)] overflow-x-auto max-w-full shrink-0"
              role="tablist"
              aria-label="Coastal Map Types"
            >
              {COASTAL_MAP_TYPES.map((map) => {
                const isSelected = map.id === activeMap.id;
                return (
                  <motion.button
                    key={map.id}
                    type="button"
                    role="tab"
                    aria-selected={isSelected}
                    onClick={() => setSelectedMapId(map.id)}
                    whileTap={prefersReducedMotion ? undefined : { scale: 0.97 }}
                    transition={SPRING_SNAPPY}
                    className={`relative px-3.5 py-2 rounded-md text-sm font-medium cursor-pointer whitespace-nowrap shrink-0 transition-colors duration-150 ${
                      isSelected
                        ? 'text-[var(--surface-canvas)]'
                        : 'text-[var(--ink-secondary)] hover:text-[var(--ink-primary)]'
                    }`}
                  >
                    {isSelected && (
                      <motion.span
                        layoutId="coastal-map-active-pill"
                        transition={SPRING_SNAPPY}
                        className="absolute inset-0 rounded-md bg-[var(--ink-primary)]"
                      />
                    )}
                    <span className="relative z-10">{map.name}</span>
                  </motion.button>
                );
              })}
            </div>
          </div>

          <div className="mt-10 grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-10 items-stretch">
            <div className="lg:col-span-5 h-full rounded-lg border border-[var(--border-hairline)] bg-[var(--surface-subtle)] p-8 md:p-10 flex flex-col justify-center">
              <AnimatePresence mode="wait">
                <motion.div
                  key={activeMap.id}
                  variants={panelVariants}
                  initial="initial"
                  animate="animate"
                  exit="exit"
                  className="space-y-3"
                >
                  <h4 className="font-display font-bold text-2xl text-[var(--ink-primary)]">
                    {activeMap.name}
                  </h4>
                  <p className="type-body text-[var(--ink-secondary)]">{activeMap.summary}</p>
                </motion.div>
              </AnimatePresence>
            </div>

            <div className="lg:col-span-7 flex">
              <MediaPlaceholder
                className="h-full"
                text="Map Image Placeholder: Top-down view of the auto-generated coastlines, curved >1 km boat routes, and decoy boat positions."
              />
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};
