import React from 'react';
import { motion, useReducedMotion } from 'motion/react';
import { TIMELINE_STEPS } from '../data/projectData';
import {
  SPRING_GENTLE,
  SPRING_SURFACE,
  getStaggerContainerVariants,
  getStaggerItemVariants,
} from '../utils/motion';

export const TimelineSection: React.FC = () => {
  const prefersReducedMotion = useReducedMotion();
  const containerVariants = getStaggerContainerVariants(prefersReducedMotion);
  const itemVariants = getStaggerItemVariants(prefersReducedMotion);

  return (
    <section
      id="timeline"
      className="py-24 md:py-32 bg-[var(--surface-subtle)] border-b border-[var(--border-hairline)]"
    >
      <div className="max-w-[1280px] mx-auto px-6 md:px-10">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: prefersReducedMotion ? 0 : 12 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={SPRING_GENTLE}
          className="max-w-3xl"
        >
          <h2
            className="type-h2 font-bold text-[var(--ink-primary)]"
            style={{ textWrap: 'balance' }}
          >
            How We Built It Step by Step
          </h2>
          <p className="mt-5 type-body text-[var(--ink-secondary)]">
            We did not start with a camera-only system. We began with the simplest setup—landing
            with a boat radio signal—discovered why standard end-to-end imitation failed in live
            flight, and solved each problem one engineering stage at a time.
          </p>
        </motion.div>

        {/* Clean 2x2 Grid with 8px Radius & 1px Hairline Borders */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.1 }}
          className="mt-14 grid grid-cols-1 lg:grid-cols-2 gap-8 items-stretch"
        >
          {TIMELINE_STEPS.map((item) => (
            <motion.article
              key={item.step}
              variants={itemVariants}
              whileHover={prefersReducedMotion ? undefined : { y: -2 }}
              transition={SPRING_SURFACE}
              className="rounded-lg border border-[var(--border-hairline)] bg-[var(--surface-elevated)] p-8 md:p-10 flex flex-col justify-between space-y-6"
            >
              <div className="space-y-4">
                <h3 className="font-display font-bold text-2xl md:text-3xl text-[var(--ink-primary)] leading-snug">
                  {item.step}. {item.title}
                </h3>
                <p className="type-body text-[var(--ink-secondary)]">{item.description}</p>
              </div>

              <div className="pt-5 border-t border-[var(--border-hairline)]">
                <p className="type-body font-semibold text-[var(--accent-primary)] leading-snug">
                  Result: {item.outcome}
                </p>
              </div>
            </motion.article>
          ))}
        </motion.div>
      </div>
    </section>
  );
};
