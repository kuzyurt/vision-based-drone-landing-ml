import React, { useEffect, useState } from 'react';
import { motion, useReducedMotion } from 'motion/react';
import { ArrowUpRight } from 'lucide-react';
import { SPRING_SNAPPY } from '../utils/motion';

const NAV_ITEMS = [
  { id: 'overview', label: 'Overview', href: '#overview' },
  { id: 'vehicles', label: 'Vehicles', href: '#vehicles' },
  { id: 'playground', label: 'Sim & Transfer', href: '#playground' },
  { id: 'timeline', label: 'Evolution', href: '#timeline' },
  { id: 'benchmarks', label: 'Benchmarks', href: '#benchmarks' },
];

export const Header: React.FC = () => {
  const [activeNav, setActiveNav] = useState<string>('overview');
  const [onDarkHero, setOnDarkHero] = useState<boolean>(true);
  const prefersReducedMotion = useReducedMotion();

  useEffect(() => {
    const handleScroll = () => {
      const heroEl = document.getElementById('hero');
      const heroBottom = heroEl ? heroEl.getBoundingClientRect().bottom : 0;
      setOnDarkHero(heroBottom > 64);
    };

    handleScroll();
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    const sectionIds = [
      'overview',
      'vehicles',
      'playground',
      'timeline',
      'architecture',
      'benchmarks',
    ];
    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) {
            const id = entry.target.id;
            setActiveNav(id === 'architecture' ? 'timeline' : id);
          }
        }
      },
      { rootMargin: '-30% 0px -55% 0px', threshold: 0 }
    );

    for (const id of sectionIds) {
      const el = document.getElementById(id);
      if (el) observer.observe(el);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <header
      className={`fixed top-0 inset-x-0 z-50 h-16 backdrop-blur-md border-b transition-colors duration-200 ${
        onDarkHero
          ? 'bg-[var(--surface-obsidian)]/85 border-[var(--border-hairline-dark)] text-white'
          : 'bg-[var(--surface-canvas)]/90 border-[var(--border-hairline)] text-[var(--ink-primary)]'
      }`}
    >
      <div className="max-w-[1280px] mx-auto h-full px-6 md:px-10 flex items-center justify-between gap-8">
        {/* Zone 1: Single text element wordmark */}
        <a
          href="#hero"
          className={`font-display font-bold text-xl tracking-tight whitespace-nowrap shrink-0 transition-colors duration-150 ${
            onDarkHero
              ? 'text-white hover:text-[var(--accent-primary-bright)]'
              : 'text-[var(--ink-primary)] hover:text-[var(--accent-primary)]'
          }`}
        >
          AeroDock
        </a>

        {/* Zone 2: 5 concise single-line text navigation links with shared-layout spring pill */}
        <nav
          aria-label="Main Navigation"
          className={`hidden md:flex items-center gap-1 p-1 rounded-lg border transition-colors duration-200 ${
            onDarkHero
              ? 'bg-[var(--surface-obsidian-raised)]/90 border-[var(--border-hairline-dark)]'
              : 'bg-[var(--surface-subtle)]/80 border-[var(--border-hairline)]'
          }`}
        >
          {NAV_ITEMS.map((item) => {
            const isActive = activeNav === item.id && !onDarkHero;
            return (
              <a
                key={item.id}
                href={item.href}
                onClick={() => setActiveNav(item.id)}
                className={`relative px-3.5 py-1.5 rounded-md text-sm font-medium whitespace-nowrap shrink-0 transition-colors duration-150 ${
                  isActive
                    ? 'text-[var(--ink-primary)] font-semibold'
                    : onDarkHero
                      ? 'text-neutral-300 hover:text-white'
                      : 'text-[var(--ink-secondary)] hover:text-[var(--ink-primary)]'
                }`}
              >
                {isActive && (
                  <motion.span
                    layoutId="header-nav-pill"
                    transition={SPRING_SNAPPY}
                    className="absolute inset-0 rounded-md bg-[var(--surface-elevated)] shadow-2xs border border-[var(--border-hairline)]"
                  />
                )}
                <span className="relative z-10">{item.label}</span>
              </a>
            );
          })}
        </nav>

        {/* Zone 3: 1 primary action */}
        <div className="flex items-center shrink-0">
          <motion.a
            href="https://github.com/kuzyurt/vision-based-drone-landing-ml"
            target="_blank"
            rel="noreferrer"
            whileHover={prefersReducedMotion ? undefined : { y: -1 }}
            whileTap={prefersReducedMotion ? undefined : { scale: 0.97 }}
            transition={SPRING_SNAPPY}
            className={`inline-flex items-center gap-1.5 px-4 py-2 rounded-md text-sm font-medium whitespace-nowrap shrink-0 transition-colors duration-150 ${
              onDarkHero
                ? 'bg-white text-[var(--ink-primary)] hover:bg-neutral-200'
                : 'bg-[var(--ink-primary)] text-[var(--surface-canvas)] hover:bg-[var(--accent-primary)]'
            }`}
          >
            <span>GitHub Repo</span>
            <ArrowUpRight className="w-4 h-4" />
          </motion.a>
        </div>
      </div>
    </header>
  );
};
