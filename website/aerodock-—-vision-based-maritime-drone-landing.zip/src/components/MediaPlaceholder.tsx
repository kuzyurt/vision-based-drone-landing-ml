import React from 'react';
import { motion, useReducedMotion } from 'motion/react';
import { SPRING_SURFACE } from '../utils/motion';

interface MediaPlaceholderProps {
  text: string;
  dark?: boolean;
  className?: string;
}

export const MediaPlaceholder: React.FC<MediaPlaceholderProps> = ({
  text,
  dark = false,
  className = '',
}) => {
  const prefersReducedMotion = useReducedMotion();

  return (
    <motion.figure
      whileHover={prefersReducedMotion ? undefined : { y: -2 }}
      transition={SPRING_SURFACE}
      className={`relative w-full aspect-video min-h-[300px] rounded-lg border flex items-center justify-center p-8 md:p-12 text-center ${
        dark
          ? 'bg-[var(--surface-obsidian-raised)] border-[var(--border-hairline-dark)] text-[var(--surface-canvas)]'
          : 'bg-[var(--surface-subtle)] border-[var(--border-hairline)] text-[var(--ink-primary)]'
      } ${className}`}
    >
      <p
        className={`max-w-lg text-lg md:text-xl font-medium leading-relaxed ${
          dark ? 'text-neutral-200' : 'text-[var(--ink-secondary)]'
        }`}
      >
        {text}
      </p>
    </motion.figure>
  );
};
