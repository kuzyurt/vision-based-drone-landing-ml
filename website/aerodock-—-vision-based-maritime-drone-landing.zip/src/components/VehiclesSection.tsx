import React from 'react';
import { motion, useReducedMotion } from 'motion/react';
import { MediaPlaceholder } from './MediaPlaceholder';
import { SPRING_GENTLE } from '../utils/motion';

export const VehiclesSection: React.FC = () => {
  const prefersReducedMotion = useReducedMotion();

  return (
    <section
      id="vehicles"
      className="py-24 md:py-32 bg-[var(--surface-subtle)] border-b border-[var(--border-hairline)]"
    >
      <div className="max-w-[1280px] mx-auto px-6 md:px-10">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: prefersReducedMotion ? 0 : 12 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={SPRING_GENTLE}
          className="max-w-3xl"
        >
          <h2
            className="type-h2 font-bold text-[var(--ink-primary)]"
            style={{ textWrap: 'balance' }}
          >
            The Boat &amp; The Drone
          </h2>
          <p className="mt-5 type-body text-[var(--ink-secondary)]">
            Before training any neural models, both the recovery vessel and the quadrotor were
            designed in <strong className="font-semibold text-[var(--ink-primary)]">FreeCAD</strong>{' '}
            and brought into{' '}
            <strong className="font-semibold text-[var(--ink-primary)]">MuJoCo</strong> as
            articulated multi-body assemblies so every mechanical actuator, wave force, and optical
            axis behaves like physical hardware.
          </p>
        </motion.div>

        {/* Vehicle 01: The Boat (Asymmetric 5/7 Split on Open Canvas) */}
        <motion.div
          initial={{ opacity: 0, y: prefersReducedMotion ? 0 : 12 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={SPRING_GENTLE}
          className="mt-16 pt-16 border-t border-[var(--border-hairline)] grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-center"
        >
          <div className="lg:col-span-5 flex flex-col justify-center space-y-5">
            <h3 className="font-display font-bold text-2xl md:text-3xl text-[var(--ink-primary)]">
              The Recovery Boat (AERODOCK)
            </h3>

            <p className="type-body text-[var(--ink-secondary)]">
              This custom 219 kg autonomous boat houses an internal drone hangar protected by two
              motorized sliding deck doors. Before landing, the doors slide open (0.46 m) and a
              scissor-lift raises the{' '}
              <strong className="font-semibold text-[var(--ink-primary)]">
                60 × 60 cm landing pad
              </strong>{' '}
              0.40 m above the deck.
            </p>

            <p className="type-body text-[var(--ink-secondary)]">
              A{' '}
              <strong className="font-semibold text-[var(--ink-primary)]">
                26 cm asymmetric cyan pattern
              </strong>{' '}
              is painted in the center of the pad so the drone’s camera can solve both 3D position
              and exact vessel heading. The simulation models 4-wave ocean buoyancy, water drag,
              dual stern thrusters, rudder steering, and bilge drainage pumps.
            </p>
          </div>

          <div className="lg:col-span-7 flex">
            <MediaPlaceholder
              className="bg-[var(--surface-elevated)]"
              text="Image & Animation Placeholder: The custom boat CAD model alongside the sliding deck doors opening while the scissor-lift raises the 60 × 60 cm landing pad."
            />
          </div>
        </motion.div>

        {/* Vehicle 02: The Drone (Reversed Asymmetric 7/5 Split on Open Canvas) */}
        <motion.div
          initial={{ opacity: 0, y: prefersReducedMotion ? 0 : 12 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={SPRING_GENTLE}
          className="mt-16 pt-16 border-t border-[var(--border-hairline)] grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-center"
        >
          <div className="lg:col-span-7 order-2 lg:order-1 flex">
            <MediaPlaceholder
              className="bg-[var(--surface-elevated)]"
              text="Image & GIF Placeholder: The Holybro X500 V2 quadrotor hovering in crosswinds while the underslung 2-axis gimbal camera pans and tilts to stay locked on target."
            />
          </div>

          <div className="lg:col-span-5 order-1 lg:order-2 flex flex-col justify-center space-y-5">
            <h3 className="font-display font-bold text-2xl md:text-3xl text-[var(--ink-primary)]">
              The Quadrotor &amp; 2-Axis Gimbal Camera
            </h3>

            <p className="type-body text-[var(--ink-secondary)]">
              Modeled after a real 2.07 kg{' '}
              <strong className="font-semibold text-[var(--ink-primary)]">
                Holybro X500 V2
              </strong>{' '}
              drone (~€1,756 in commercial parts: Pixhawk 6C flight controller, Khadas Edge 2
              onboard computer, and an optional{' '}
              <strong className="font-semibold text-[var(--ink-primary)]">SX1262</strong> sub-GHz
              radio receiver). It is flown by real, unmodified{' '}
              <strong className="font-semibold text-[var(--ink-primary)]">PX4 Autopilot</strong>{' '}
              firmware running at 250 Hz.
            </p>

            <p className="type-body text-[var(--ink-secondary)]">
              In strong crosswinds, a quadrotor has to tilt steeply into the wind just to hold its
              course—so a fixed camera would immediately lose sight of the boat. To solve this, an
              underslung{' '}
              <strong className="font-semibold text-[var(--ink-primary)]">
                2-axis gimbal camera
              </strong>{' '}
              (640 × 360 at 25 Hz) pans 360° and tilts independently to keep the deck centered in
              view.
            </p>
          </div>
        </motion.div>
      </div>
    </section>
  );
};
