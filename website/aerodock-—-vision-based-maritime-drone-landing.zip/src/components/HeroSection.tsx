import React, { useEffect, useState } from 'react';
import { AnimatePresence, motion, useReducedMotion } from 'motion/react';
import { ArrowDown } from 'lucide-react';
import { resolveInitialHeroPhase } from '../data/projectData';
import {
  EXIT_ASYMMETRIC,
  REDUCED_MOTION_TRANSITION,
  SPRING_GENTLE,
  SPRING_SURFACE,
} from '../utils/motion';

export const HeroSection: React.FC = () => {
  const prefersReducedMotion = useReducedMotion();
  const [phase, setPhase] = useState<'title_intro' | 'video_playing' | 'video_ended'>(() =>
    typeof window !== 'undefined'
      ? resolveInitialHeroPhase(window.location.search)
      : 'title_intro'
  );

  useEffect(() => {
    if (phase !== 'title_intro') return;
    const timer = window.setTimeout(() => {
      setPhase('video_playing');
    }, 2400);
    return () => window.clearTimeout(timer);
  }, [phase]);

  useEffect(() => {
    if (phase !== 'video_playing') return;
    const timer = window.setTimeout(() => {
      setPhase('video_ended');
    }, 2200);
    return () => window.clearTimeout(timer);
  }, [phase]);

  return (
    <section
      id="hero"
      className="relative min-h-screen w-full pt-16 bg-[var(--surface-obsidian)] text-[var(--surface-canvas)] flex flex-col items-center justify-center border-b border-[var(--border-hairline-dark)] overflow-hidden"
    >
      <div className="max-w-[1280px] w-full mx-auto px-6 md:px-10 py-12 flex items-center justify-center">
        <AnimatePresence mode="wait">
          {phase === 'title_intro' ? (
            <motion.div
              key="hero-title-intro"
              initial={
                prefersReducedMotion ? { opacity: 0 } : { opacity: 0, y: 14, scale: 0.985 }
              }
              animate={
                prefersReducedMotion
                  ? { opacity: 1, transition: REDUCED_MOTION_TRANSITION }
                  : { opacity: 1, y: 0, scale: 1, transition: SPRING_GENTLE }
              }
              exit={
                prefersReducedMotion
                  ? { opacity: 0, transition: REDUCED_MOTION_TRANSITION }
                  : {
                      opacity: 0,
                      y: -8,
                      scale: 0.985,
                      transition: EXIT_ASYMMETRIC,
                    }
              }
              className="w-full grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-end"
            >
              <div className="lg:col-span-8">
                <h1
                  className="type-display font-bold text-white"
                  style={{ textWrap: 'balance' }}
                >
                  Autonomous Drone Landing on a Moving Boat
                </h1>
              </div>

              <div className="lg:col-span-4 lg:border-l lg:border-[var(--border-hairline-dark)] lg:pl-8">
                <p className="text-xl text-neutral-300 leading-relaxed">
                  Finding a moving vessel at sea by camera, tracking its pitching deck through waves
                  and wind, and landing autonomously.
                </p>
              </div>
            </motion.div>
          ) : (
            <motion.div
              key="hero-video-stage"
              initial={
                prefersReducedMotion ? { opacity: 0 } : { opacity: 0, y: 12, scale: 0.985 }
              }
              animate={
                prefersReducedMotion
                  ? { opacity: 1, transition: REDUCED_MOTION_TRANSITION }
                  : {
                      opacity: 1,
                      y: 0,
                      scale: 1,
                      transition: SPRING_SURFACE,
                    }
              }
              exit={
                prefersReducedMotion
                  ? { opacity: 0, transition: REDUCED_MOTION_TRANSITION }
                  : {
                      opacity: 0,
                      y: -6,
                      scale: 0.985,
                      transition: EXIT_ASYMMETRIC,
                    }
              }
              className="w-full aspect-video max-h-[72vh] rounded-lg border border-[var(--border-hairline-dark)] bg-[var(--surface-obsidian-raised)] p-10 md:p-16 flex items-center justify-center text-center"
            >
              <p className="max-w-2xl font-display font-semibold text-2xl md:text-3xl text-white leading-snug">
                Video Placeholder: The recovery boat cruising across ocean waves near a rocky beach
                coastline while the drone approaches and lands autonomously on the moving deck.
              </p>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Bottom-middle scroll indicator */}
      <AnimatePresence>
        {phase === 'video_ended' && (
          <motion.a
            key="hero-scroll-prompt"
            href="#overview"
            data-testid="hero-scroll-indicator"
            initial={prefersReducedMotion ? { opacity: 0 } : { opacity: 0, y: 8 }}
            animate={
              prefersReducedMotion
                ? { opacity: 1, transition: REDUCED_MOTION_TRANSITION }
                : { opacity: 1, y: 0, transition: SPRING_SURFACE }
            }
            whileHover={prefersReducedMotion ? undefined : { y: 2 }}
            className="absolute bottom-8 left-1/2 -translate-x-1/2 inline-flex items-center gap-2 text-base font-medium text-neutral-300 hover:text-white transition-colors duration-150 cursor-pointer"
          >
            <span>Scroll down</span>
            <ArrowDown className="w-4 h-4 text-[var(--accent-primary-bright)]" />
          </motion.a>
        )}
      </AnimatePresence>
    </section>
  );
};
