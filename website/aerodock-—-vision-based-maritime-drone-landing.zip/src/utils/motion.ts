import type { Transition, Variants } from 'motion/react';

/**
 * Emil Kowalski & Julien Thibeaut (ui-skills) Motion Engineering Spec:
 * - Never animate from scale(0) (use >= 0.95)
 * - Never leave scroll-reveal text blurred with filter: blur()
 * - Only animate compositor properties (transform, opacity)
 * - Fast, responsive spring physics and asymmetric exit timing (< 200ms)
 */

export const SPRING_SNAPPY: Transition = {
  type: 'spring',
  stiffness: 400,
  damping: 28,
  mass: 0.8,
};

export const SPRING_SURFACE: Transition = {
  type: 'spring',
  stiffness: 260,
  damping: 25,
  mass: 1,
};

export const SPRING_GENTLE: Transition = {
  type: 'spring',
  stiffness: 140,
  damping: 24,
  mass: 1.1,
};

export const EXIT_ASYMMETRIC: Transition = {
  duration: 0.15,
  ease: [0.32, 0, 0.67, 0],
};

export const REDUCED_MOTION_TRANSITION: Transition = {
  duration: 0.15,
  ease: 'linear',
};

export function getStaggerContainerVariants(prefersReducedMotion: boolean | null): Variants {
  if (prefersReducedMotion) {
    return {
      hidden: { opacity: 0 },
      visible: {
        opacity: 1,
        transition: REDUCED_MOTION_TRANSITION,
      },
    };
  }

  return {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.05,
        delayChildren: 0.03,
      },
    },
  };
}

export function getStaggerItemVariants(prefersReducedMotion: boolean | null): Variants {
  if (prefersReducedMotion) {
    return {
      hidden: { opacity: 0 },
      visible: {
        opacity: 1,
        transition: REDUCED_MOTION_TRANSITION,
      },
      exit: {
        opacity: 0,
        transition: REDUCED_MOTION_TRANSITION,
      },
    };
  }

  return {
    hidden: {
      opacity: 0,
      y: 10,
    },
    visible: {
      opacity: 1,
      y: 0,
      transition: SPRING_GENTLE,
    },
    exit: {
      opacity: 0,
      y: -6,
      scale: 0.98,
      transition: EXIT_ASYMMETRIC,
    },
  };
}

export function getPanelSwapVariants(prefersReducedMotion: boolean | null): Variants {
  if (prefersReducedMotion) {
    return {
      initial: { opacity: 0 },
      animate: { opacity: 1, transition: REDUCED_MOTION_TRANSITION },
      exit: { opacity: 0, transition: REDUCED_MOTION_TRANSITION },
    };
  }

  return {
    initial: {
      opacity: 0,
      y: 6,
      scale: 0.985,
    },
    animate: {
      opacity: 1,
      y: 0,
      scale: 1,
      transition: SPRING_SURFACE,
    },
    exit: {
      opacity: 0,
      y: -4,
      scale: 0.985,
      transition: EXIT_ASYMMETRIC,
    },
  };
}
