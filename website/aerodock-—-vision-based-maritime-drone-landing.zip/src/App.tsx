/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { ArrowUpRight } from 'lucide-react';
import { Header } from './components/Header';
import { HeroSection } from './components/HeroSection';
import { OverviewSection } from './components/OverviewSection';
import { VehiclesSection } from './components/VehiclesSection';
import { PlaygroundSection } from './components/PlaygroundSection';
import { TimelineSection } from './components/TimelineSection';
import { ArchitectureSection } from './components/ArchitectureSection';
import { BenchmarkSection } from './components/BenchmarkSection';

export default function App() {
  return (
    <div className="min-h-screen flex flex-col bg-[var(--surface-canvas)] text-[var(--ink-primary)]">
      <Header />

      <main className="flex-1">
        <HeroSection />
        <OverviewSection />
        <VehiclesSection />
        <PlaygroundSection />
        <TimelineSection />
        <ArchitectureSection />
        <BenchmarkSection />
      </main>

      <footer className="bg-[var(--surface-canvas)] border-t border-[var(--border-hairline)] py-12">
        <div className="max-w-[1280px] mx-auto px-6 md:px-10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
          <span className="font-display font-bold text-lg text-[var(--ink-primary)]">
            AeroDock — Autonomous Drone Landing on a Moving Boat
          </span>

          <a
            href="https://github.com/kuzyurt/vision-based-drone-landing-ml"
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-2 px-4 py-2 rounded-md border border-[var(--border-hairline)] bg-[var(--surface-elevated)] text-sm font-medium text-[var(--ink-primary)] hover:border-[var(--ink-primary)] transition-colors duration-150"
          >
            <span>View on GitHub</span>
            <ArrowUpRight className="w-4 h-4" />
          </a>
        </div>
      </footer>
    </div>
  );
}
